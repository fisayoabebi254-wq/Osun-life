# OSUN LIFE — online multiplayer life simulation

This is a runnable, phone-friendly browser game project with a generated 3D town scene, accounts, persistent player profiles, real-time player presence/movement, live town chat, jobs and earnings, XP/levels, a shop, inventory, home ownership, vehicle ownership, friends, and a relationship-status profile option.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Set a strong `JWT_SECRET` environment variable.
4. Run `npm start` and open `http://localhost:3000`.

The Three.js client is loaded from jsDelivr, so the game needs an internet connection to load the 3D library. Socket.IO is served by the app itself.

## Upload to GitHub from a phone
1. Unzip this project on your phone if needed.
2. In your `osun-life` GitHub repository, choose **Add file → Upload files**.
3. Upload the *contents* of this folder (especially `server.js`, `package.json`, `README.md`, and the `public` folder). Keep the folder structure; `index.html`, `style.css`, and `game.js` must remain inside `public/`.
4. Commit the upload.

## Deploy as an online game
Deploy the repository as a **Node Web Service** on a host such as Render. Build command: `npm install`. Start command: `npm start`. Set `JWT_SECRET` to a long random value in the host's environment settings. Add a persistent disk mounted at `/opt/render/project/src/data` (or configure persistent storage for the host) because this starter stores account data in `data/users.json`. Without persistent storage, many hosts erase local files during redeploy/restart. Use HTTPS for public use.

## Important limits / next production steps
This is a functional playable foundation, not a finished commercial-scale 3D MMO. The town is built from procedural shapes; cars are owned in the garage but are not yet drivable; houses are account ownership rather than enterable interiors; the social relationship feature stores a status rather than a full relationship system. For a public launch, move user data to a managed database, configure a strong secret, add moderation/reporting and rate limiting, and load-test multiplayer. Do not reuse the fallback JWT secret in production.
