const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: true } });
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET_BEFORE_PUBLIC_DEPLOYMENT_OSUN_LIFE';
const DATA_DIR = path.join(__dirname, 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const WORLD_FILE = path.join(DATA_DIR, 'world.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, data) { const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(data, null, 2)); fs.renameSync(tmp, file); }
let users = readJson(USERS_FILE, {});
let world = readJson(WORLD_FILE, {});
const online = new Map();
const chatHistory = [];
const jobs = { trader: { label: 'Market Trader', pay: 75 }, courier: { label: 'Courier', pay: 110 }, mechanic: { label: 'Mechanic', pay: 125 }, creator: { label: 'Content Creator', pay: 90 } };
const catalog = [
 {id:'adire',name:'Adire Outfit',price:180,type:'clothing'}, {id:'sneakers',name:'Fresh Sneakers',price:120,type:'clothing'},
 {id:'phone',name:'Smartphone',price:250,type:'item'}, {id:'snack',name:'Osun Snack',price:25,type:'food'},
 {id:'bicycle',name:'Bicycle',price:500,type:'vehicle'}, {id:'compact',name:'Town Car',price:1800,type:'vehicle'}
];
function freshPlayer(name) { return { name, cash:500, level:1, xp:0, job:'trader', x:0, z:0, home:'No home yet', inventory:[], vehicles:[], friends:[], relationshipStatus:'Single', createdAt:Date.now() }; }
function publicPlayer(u) { return { name:u.name, cash:u.cash, level:u.level, job:u.job, x:u.x||0, z:u.z||0, home:u.home, relationshipStatus:u.relationshipStatus }; }
function auth(req,res,next) { const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,''); try { const payload=jwt.verify(token,SECRET); if(!users[payload.id]) return res.status(401).json({error:'Account not found'}); req.userId=payload.id; req.user=users[payload.id]; next(); } catch { res.status(401).json({error:'Please sign in again'}); } }
app.use(express.json({limit:'64kb'}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/api/health',(_,res)=>res.json({ok:true,game:'Osun Life',online:online.size}));
app.post('/api/register', async (req,res)=>{
 const name=String(req.body.name||'').trim().replace(/\s+/g,' '); const email=String(req.body.email||'').trim().toLowerCase(); const password=String(req.body.password||'');
 if(name.length<2||name.length>18||!/^[\p{L}\p{N}_ -]+$/u.test(name)) return res.status(400).json({error:'Name must be 2–18 letters, numbers, spaces, _ or -.'});
 if(!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({error:'Enter a valid email address.'});
 if(password.length<8) return res.status(400).json({error:'Password must be at least 8 characters.'});
 if(Object.values(users).some(u=>u.email===email)) return res.status(409).json({error:'That email already has an account. Sign in instead.'});
 const id=require('crypto').randomUUID(); users[id]={id,email,passwordHash:await bcrypt.hash(password,10),...freshPlayer(name)}; writeJson(USERS_FILE,users);
 res.json({token:jwt.sign({id},SECRET,{expiresIn:'30d'}),player:publicPlayer(users[id])});
});
app.post('/api/login',async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||''); const pair=Object.entries(users).find(([,u])=>u.email===email); if(!pair||!await bcrypt.compare(password,pair[1].passwordHash))return res.status(401).json({error:'Email or password is incorrect.'}); res.json({token:jwt.sign({id:pair[0]},SECRET,{expiresIn:'30d'}),player:publicPlayer(pair[1])});});
app.get('/api/me',auth,(req,res)=>res.json({player:publicPlayer(req.user),inventory:req.user.inventory,vehicles:req.user.vehicles,friends:req.user.friends,catalog,jobs}));
app.get('/api/players',auth,(_,res)=>res.json([...online.values()].map(p=>({name:p.name,x:p.x,z:p.z,job:p.job,level:p.level}))));
app.post('/api/action',auth,(req,res)=>{
 const u=req.user, a=String(req.body.action||''); let msg='';
 if(a==='work') { const job=jobs[u.job]||jobs.trader; u.cash+=job.pay; u.xp=(u.xp||0)+25; if(u.xp>=100){u.xp-=100;u.level=(u.level||1)+1;} msg=`Shift complete! You earned ₦${job.pay}.`; }
 else if(a==='job'){if(!jobs[req.body.job])return res.status(400).json({error:'That job is unavailable.'});u.job=req.body.job;msg=`You are now a ${jobs[u.job].label}.`;}
 else if(a==='buy') {const item=catalog.find(x=>x.id===req.body.item);if(!item)return res.status(400).json({error:'Item not found.'});if(u.cash<item.price)return res.status(400).json({error:'Not enough Osun coins yet. Try a job first.'});u.cash-=item.price;if(item.type==='vehicle')u.vehicles.push(item.id);else u.inventory.push(item.id);msg=`Bought ${item.name}!`;}
 else if(a==='home'){const homes={'room':{label:'Shared Room',price:350},'flat':{label:'Osogbo Flat',price:1200},'house':{label:'Family House',price:3000}};const h=homes[req.body.home];if(!h)return res.status(400).json({error:'Home not found.'});if(u.cash<h.price)return res.status(400).json({error:'Not enough Osun coins for this home.'});u.cash-=h.price;u.home=h.label;msg=`Welcome to your ${h.label}!`;}
 else if(a==='friend'){const target=String(req.body.name||'').trim();if(!target||target.toLowerCase()===u.name.toLowerCase())return res.status(400).json({error:'Choose another player.'});const found=Object.values(users).find(x=>x.name.toLowerCase()===target.toLowerCase());if(!found)return res.status(404).json({error:'Player not found. They need to create an account first.'});if(!u.friends.includes(found.name))u.friends.push(found.name);if(!found.friends.includes(u.name))found.friends.push(u.name);msg=`${found.name} added to your friends.`;writeJson(USERS_FILE,users);}
 else if(a==='relationship'){const status=String(req.body.status||'');if(!['Single','Open to meeting people','In a relationship'].includes(status))return res.status(400).json({error:'Choose a valid status.'});u.relationshipStatus=status;msg=`Relationship status updated: ${status}.`;}
 else if(a==='move'){u.x=Math.max(-100,Math.min(100,Number(req.body.x)||0));u.z=Math.max(-100,Math.min(100,Number(req.body.z)||0));}
 else return res.status(400).json({error:'Unknown action.'});
 writeJson(USERS_FILE,users);res.json({message:msg,player:publicPlayer(u),inventory:u.inventory,vehicles:u.vehicles,friends:u.friends});
});
function socketUser(socket){try{const p=jwt.verify(socket.handshake.auth?.token||'',SECRET);return users[p.id]?{id:p.id,user:users[p.id]}:null;}catch{return null;}}
io.on('connection',socket=>{const pair=socketUser(socket);if(!pair){socket.disconnect(true);return;}const {id,user}=pair;online.set(id,{id,name:user.name,x:user.x||0,z:user.z||0,job:user.job,level:user.level||1,socketId:socket.id});socket.join('world');io.to('world').emit('players', [...online.values()].map(p=>({id:p.id,name:p.name,x:p.x,z:p.z,job:p.job,level:p.level})));socket.emit('chat-history',chatHistory);
 socket.on('move',pos=>{if(!pos||!Number.isFinite(pos.x)||!Number.isFinite(pos.z))return;const p=online.get(id);if(!p)return;p.x=Math.max(-100,Math.min(100,pos.x));p.z=Math.max(-100,Math.min(100,pos.z));user.x=p.x;user.z=p.z;socket.to('world').emit('player-moved',{id,x:p.x,z:p.z});});
 socket.on('chat',raw=>{const text=String(raw||'').trim().slice(0,240);if(!text)return;const entry={name:user.name,text,at:Date.now()};chatHistory.push(entry);if(chatHistory.length>60)chatHistory.shift();io.to('world').emit('chat-message',entry);});
 socket.on('disconnect',()=>{online.delete(id);writeJson(USERS_FILE,users);io.to('world').emit('players',[...online.values()].map(p=>({id:p.id,name:p.name,x:p.x,z:p.z,job:p.job,level:p.level})));});
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Osun Life running on ${PORT}`));
